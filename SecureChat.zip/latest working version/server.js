// server.js
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http, {
    // Increase the maximum HTTP buffer size to handle large media files
    maxHttpBufferSize: 1e8 // 100 MB
});
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => console.log(`Listening on port ${PORT}`));

app.use(express.static(__dirname + '/public'));

app.get('/', (req, res) => res.sendFile(__dirname + '/index.html'));

const rooms = {};

io.on('connection', (socket) => {
    console.log('Connected...');

    // Handle name checking for uniqueness
    socket.on('check_name', ({ name, roomCode, action }) => {
        const room = rooms[roomCode];
        if (room && Array.from(room.users.values()).some(user => user.name === name)) {
            socket.emit('name_taken');
        } else {
            socket.emit('name_accepted', { action });
        }
    });

    // Handle room creation
    socket.on('create_room', ({ roomCode, name, secureChat }) => {
        socket.join(roomCode);

        if (!rooms[roomCode]) {
            let encryptionKey = null;
            if (secureChat) {
                encryptionKey = crypto.randomBytes(32).toString('hex'); // 256-bit key
            }
            rooms[roomCode] = { 
                admin: socket.id, 
                users: new Map(), 
                chatBlocked: false, 
                roomLocked: false,
                secureChat: secureChat || false,
                encryptionKey: encryptionKey,
                blockedUsers: new Set()
            };
            socket.emit('assign_admin');
        }
        
        rooms[roomCode].users.set(socket.id, { name, isAdmin: rooms[roomCode].admin === socket.id });
        updateRoomUserCount(roomCode);
        socket.emit('room_created', { roomCode, admin: true, secureChat: rooms[roomCode].secureChat });

        // If secureChat is enabled, send the encryption key to the admin
        if (rooms[roomCode].secureChat) {
            socket.emit('encryption_key', rooms[roomCode].encryptionKey);
        }

        emitUserList(roomCode);
    });

    // Handle joining a room
    socket.on('join_room', ({ roomCode, name }) => {
        const room = rooms[roomCode];

        if (room && !room.roomLocked) {
            socket.join(roomCode);
            room.users.set(socket.id, { name, isAdmin: false });
            updateRoomUserCount(roomCode);
            socket.emit('room_joined', { roomCode, chatBlocked: room.chatBlocked, secureChat: room.secureChat });

            // If secureChat is enabled, send the encryption key to the new user
            if (room.secureChat) {
                socket.emit('encryption_key', room.encryptionKey);
            }

            io.in(roomCode).emit('message', { user: 'Server', message: `${name} has joined the room.` });
            emitUserList(roomCode);
        } else {
            socket.emit('room_locked', true);
        }
    });

    // Handle setting the user's name and role
    socket.on('set_name', ({ name, roomCode }) => {
        const room = rooms[roomCode];
        if (room && room.admin === socket.id) {
            socket.emit('assign_admin');
        }
    });

    // Handle incoming messages
    socket.on('message', ({ msg, roomCode }) => {
        const room = rooms[roomCode];
        
        if (room && (!room.chatBlocked || room.admin === socket.id)) {
            if (room.secureChat) {
                // Forward the encrypted message and media as-is
                io.in(roomCode).emit('message', { 
                    user: msg.user, 
                    message: msg.message, 
                    image: msg.image, 
                    audio: msg.audio,
                    video: msg.video,
                    senderId: socket.id 
                });
            } else {
                // Forward the message and media normally
                io.in(roomCode).emit('message', { 
                    user: msg.user, 
                    message: msg.message, 
                    image: msg.image, 
                    audio: msg.audio,
                    video: msg.video,
                    senderId: socket.id 
                });
            }
        }
    });

    // Handle toggling chat block by admin
    socket.on('toggle_block_chat', ({ roomCode, chatBlocked }) => {
        const room = rooms[roomCode];
        if (room && room.admin === socket.id) {
            room.chatBlocked = chatBlocked;
            io.in(roomCode).emit('chat_blocked', chatBlocked);
        }
    });

    // Handle toggling room lock by admin
    socket.on('toggle_room_lock', ({ roomCode, roomLocked }) => {
        const room = rooms[roomCode];
        if (room && room.admin === socket.id) {
            room.roomLocked = roomLocked;
            io.in(roomCode).emit('room_locked', roomLocked);
        }
    });

    // Handle user list requests
    socket.on('request_user_list', (roomCode) => {
        if (rooms[roomCode]) {
            const users = Array.from(rooms[roomCode].users.entries()).map(([id, user]) => ({
                id,
                name: user.name,
                isAdmin: user.isAdmin,
                blocked: rooms[roomCode].blockedUsers.has(id)
            }));
            socket.emit('update_user_list', users);
        }
    });

    // Handle making a user admin
    socket.on('make_admin', ({ roomCode, userId }) => {
        const room = rooms[roomCode];
        if (room && room.admin === socket.id && room.users.has(userId)) {
            // Demote current admin
            room.users.get(room.admin).isAdmin = false;
            // Promote new admin
            room.admin = userId;
            room.users.get(userId).isAdmin = true;
            io.in(roomCode).emit('update_user_list', Array.from(room.users.entries()).map(([id, user]) => ({
                id,
                name: user.name,
                isAdmin: user.isAdmin,
                blocked: room.blockedUsers.has(id)
            })));
            io.to(userId).emit('assign_admin');

            // If secureChat is enabled, resend the encryption key to the new admin
            if (room.secureChat && room.encryptionKey) {
                io.to(userId).emit('encryption_key', room.encryptionKey);
            }
        }
    });

    // Handle blocking/unblocking a user 
    socket.on('block_user', ({ roomCode, userId, block }) => {
        const room = rooms[roomCode];
        if (room && room.admin === socket.id && room.users.has(userId)) {
            if (block) {
                room.blockedUsers.add(userId);
            } else {
                room.blockedUsers.delete(userId);
            }
            io.in(roomCode).emit('user_blocked', { userId, block });
            emitUserList(roomCode);
        }
    });

    // Handle kicking a user
    socket.on('kick_user', ({ roomCode, userId }) => {
        const room = rooms[roomCode];
        if (room && room.admin === socket.id && room.users.has(userId)) {
            io.to(userId).emit('kicked');
            io.sockets.sockets.get(userId)?.leave(roomCode);
            const kickedUserName = room.users.get(userId).name;
            room.users.delete(userId);
            room.blockedUsers.delete(userId);
            updateRoomUserCount(roomCode);
            io.in(roomCode).emit('message', { user: 'Server', message: `${kickedUserName} has been kicked from the room.` });
            emitUserList(roomCode);
        }
    });

    // Handle user disconnection
    socket.on('disconnect', () => {
        for (const roomCode in rooms) {
            const room = rooms[roomCode];
            if (room.users.has(socket.id)) {
                const userName = room.users.get(socket.id).name;
                room.users.delete(socket.id);
                room.blockedUsers.delete(socket.id);
                
                if (room.admin === socket.id && room.users.size > 0) {
                    const newAdmin = Array.from(room.users.keys())[0];
                    room.admin = newAdmin;
                    room.users.get(newAdmin).isAdmin = true;
                    io.to(newAdmin).emit('assign_admin');

                    // If secureChat is enabled, resend the encryption key to the new admin
                    if (room.secureChat && room.encryptionKey) {
                        io.to(newAdmin).emit('encryption_key', room.encryptionKey);
                    }
                }

                if (room.users.size === 0) {
                    delete rooms[roomCode];
                } else {
                    io.in(roomCode).emit('message', { user: 'Server', message: `${userName} has left the room.` });
                    updateRoomUserCount(roomCode);
                    emitUserList(roomCode);
                }
                break;
            }
        }
    });

    // Handle incoming media files
    socket.on('media', ({ roomCode, media }) => {
        const room = rooms[roomCode];
        if (room && room.users.has(socket.id)) {
            // Broadcast the media to other users in the room without revealing the user's name
            socket.to(roomCode).emit('media', { 
                media,
                senderId: socket.id 
            });
        }
    });

    // Function to update user count in a room
    function updateRoomUserCount(roomCode) {
        const room = rooms[roomCode];
        if (room) {
            io.in(roomCode).emit('update_user_count', room.users.size);
        }
    }

    // Function to emit updated user list to the room
    function emitUserList(roomCode) {
        const room = rooms[roomCode];
        if (!room) return;
        const users = Array.from(room.users.entries()).map(([id, user]) => ({
            id,
            name: user.name,
            isAdmin: user.isAdmin,
            blocked: room.blockedUsers.has(id)
        }));
        io.in(roomCode).emit('update_user_list', users);
    } 
});
