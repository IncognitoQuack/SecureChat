// client.js
const socket = io();
let name, roomCode;
let isAdmin = false;
let chatBlocked = false;
let userCount = 0;
let secureChat = false;
let encryptionKey = null;
let blockedUsers = new Set();

const roomSection = document.querySelector('.room__section');
const chatSection = document.querySelector('.chat__section');
const messageArea = document.querySelector('.message__area');
const textarea = document.querySelector('#textarea');
const roomTitle = document.getElementById('roomTitle');
const roomCodeDisplay = document.getElementById('roomCodeDisplay');
const userCountButton = document.getElementById('userCount');
const userModal = document.getElementById('userModal');
const userList = document.getElementById('userList');
const closeModal = document.getElementById('closeModal');
const controlChatButton = document.getElementById('controlChatButton');
const controlRoomButton = document.getElementById('controlRoomButton');
const adminControls = document.querySelector('.admin-controls');
const dropZone = document.getElementById('dropZone'); // Ensure this element exists in your HTML
const mediaUrlInput = document.getElementById('mediaUrlInput'); // Ensure this element exists in your HTML
const uploadUrlButton = document.getElementById('uploadUrlButton'); // Ensure this element exists in your HTML

// Hide admin controls initially
adminControls.style.display = 'none';

// Event listener for creating a room
document.getElementById('createRoom').addEventListener('click', () => {
    roomCode = generateRoomCode();
    
    // Retrieve the Secure Chat option from the UI
    const secureChatCheckbox = document.getElementById('secureChatOption');
    secureChat = secureChatCheckbox.checked;
    
    promptForUniqueName('create');
});

// Event listener for joining a room
document.getElementById('joinRoom').addEventListener('click', () => {
    roomCode = document.getElementById('roomCode').value.trim();
    if (roomCode === '') {
        alert('Please enter a valid Room Code.');
        return;
    }
    promptForUniqueName('join');
});

// Function to prompt user for a unique name
function promptForUniqueName(action) {
    name = prompt('Enter your name:');
    if (!name) return;

    // Check name uniqueness with the server
    socket.emit('check_name', { name, roomCode, action });
}

// Handle name taken scenario
socket.on('name_taken', () => {
    alert('Name already taken. Please choose a different name.');
    promptForUniqueName('join');
});

// Handle name acceptance
socket.on('name_accepted', ({ action }) => {
    if (action === 'create') {
        socket.emit('create_room', { roomCode, name, secureChat }); // Send secureChat flag
    } else {
        socket.emit('join_room', { roomCode, name });
    }
});

// Handle room creation
socket.on('room_created', ({ roomCode, admin, secureChat: roomSecureChat }) => {
    secureChat = roomSecureChat; // Update secureChat status based on server response
    initializeChat();
});

// Handle room joining
socket.on('room_joined', ({ roomCode, chatBlocked: initialChatBlocked, secureChat: roomSecureChat }) => {
    secureChat = roomSecureChat; // Update secureChat status based on server response
    initializeChat();
    chatBlocked = initialChatBlocked;
    textarea.disabled = chatBlocked && !isAdmin; 
});

// Function to initialize the chat interface
function initializeChat() {
    // Hide the room creation/join section and display the chat section
    roomSection.style.display = 'none';
    chatSection.style.display = 'block';

    roomCodeDisplay.textContent = roomCode;

    socket.emit('set_name', { name, roomCode });
}

// Handle receiving the encryption key from the server
socket.on('encryption_key', (key) => {
    encryptionKey = key;
});

// Admin setup for chat and room control buttons
socket.on('assign_admin', () => {
    isAdmin = true;
    adminControls.style.display = 'block';
    userCountButton.style.display = 'inline-block';
});

// Function to toggle chat blocking
function toggleChatBlock() {
    chatBlocked = !chatBlocked;
    controlChatButton.textContent = chatBlocked ? 'Unblock Chat' : 'Block Chat';
    socket.emit('toggle_block_chat', { roomCode, chatBlocked });
}

// Function to toggle room locking
function toggleRoomLock() {
    const isLocking = controlRoomButton.textContent === 'Lock Room';
    controlRoomButton.textContent = isLocking ? 'Unlock Room' : 'Lock Room';
    socket.emit('toggle_room_lock', { roomCode, roomLocked: isLocking });
}

// Event listeners for admin buttons
controlChatButton.addEventListener('click', toggleChatBlock);
controlRoomButton.addEventListener('click', toggleRoomLock);

// Event listener for sending messages on Enter key
textarea.addEventListener('keyup', (e) => {
    if (e.key === 'Enter' && !textarea.disabled) {
        e.preventDefault();
        sendMessage(e.target.value);
    }
});

// Function to send a message
/**
 * Sends a message.
 * @param {string} message - The text message to send.
 */
function sendMessage(message) {
    if (!isAdmin && chatBlocked) return;
    if (message.trim() === '') return;

    if (blockedUsers.has(socket.id)) {
        return;
    }

    let encryptedMessage = message.trim();

    if (secureChat && encryptionKey) {
        if (message.trim() !== '') {
            encryptedMessage = CryptoJS.AES.encrypt(message.trim(), encryptionKey).toString();
        }
    }

    let msg = { 
        user: name, 
        message: encryptedMessage,
        senderId: socket.id 
    };

    // Display the message locally with decrypted content
    appendMessage({ user: name, message: message.trim() }, 'outgoing');
    textarea.value = '';
    socket.emit('message', { msg, roomCode });
}

// Handle incoming messages
socket.on('message', (msg) => {
    if (msg.senderId !== socket.id) {
        if (blockedUsers.has(msg.senderId)) return;
        let decryptedMessage = msg.message;

        if (secureChat && encryptionKey) {
            try {
                const bytes = CryptoJS.AES.decrypt(msg.message, encryptionKey);
                decryptedMessage = bytes.toString(CryptoJS.enc.Utf8);
            } catch (e) {
                console.error('Decryption failed for message:', e);
                decryptedMessage = '[Decryption Failed]';
            }
        }

        appendMessage({ user: msg.user, message: decryptedMessage }, 'incoming');
    }
});

// Handle incoming media
socket.on('media', ({ media, senderId }) => {
    if (blockedUsers.has(senderId)) return;

    let mediaType = '';
    if (media.startsWith('data:image/')) {
        mediaType = 'image';
    } else if (media.startsWith('data:audio/')) {
        mediaType = 'audio';
    } else if (media.startsWith('data:video/')) {
        mediaType = 'video';
    }

    appendMedia({ media, type: mediaType }, 'incoming');
});

// Handle chat block status
socket.on('chat_blocked', (blocked) => {
    chatBlocked = blocked;
    textarea.disabled = blocked && !isAdmin;
});

// Update user count in the UI
socket.on('update_user_count', (count) => {
    userCount = count;
    userCountButton.textContent = `${userCount} User${count !== 1 ? 's' : ''}`;
});

// Update user list in the modal
socket.on('update_user_list', (users) => {
    userList.innerHTML = ''; // Clear previous user list
    users.forEach(user => {
        const li = document.createElement('li');
        li.innerHTML = `<span style="color: ${user.isAdmin ? 'gold' : 'black'};">${user.name}</span>`;

        if (isAdmin && user.id !== socket.id) {
            const actionsDiv = document.createElement('div');

                const kickUserBtn = document.createElement('button');
                kickUserBtn.textContent = 'Kick';
                kickUserBtn.classList.add('action-button', 'kick'); 
                kickUserBtn.addEventListener('click', () => {
                    socket.emit('kick_user', { roomCode, userId: user.id });
                });
        
                const blockUserBtn = document.createElement('button');
                blockUserBtn.textContent = 'Block';
                blockUserBtn.classList.add('action-button', 'block');
                blockUserBtn.addEventListener('click', () => {
                    socket.emit('block_user', { roomCode, userId: user.id, block: true });
                });
        
                actionsDiv.appendChild(kickUserBtn);
                actionsDiv.appendChild(blockUserBtn);
            

            li.appendChild(actionsDiv);
        }

        userList.appendChild(li);
    });
});

// Handle assigning new admin
socket.on('new_admin', () => {
    isAdmin = true;
    adminControls.style.display = 'block';
    userCountButton.style.display = 'inline-block';
});

// Handle user blocked
socket.on('user_blocked', ({ userId, block }) => {
    if (block) {
        blockedUsers.add(userId);
    } else {
        blockedUsers.delete(userId);
    }
    if (userId === socket.id && block) {
        textarea.disabled = true;
    } else if (userId === socket.id && !block) {
        textarea.disabled = false;
    }
});

// Handle being kicked
socket.on('kicked', () => {
    alert('You have been kicked from the room.');
    window.location.reload();
});

// Function to display the user list modal
function showUserList() {
    socket.emit('request_user_list', roomCode);
    userModal.style.display = 'block';
}

// Event listener to close the user list modal
closeModal.addEventListener('click', () => {
    userModal.style.display = 'none';
});

// Event listener for user count button
userCountButton.addEventListener('click', showUserList);

// Close the user list modal when clicking outside the modal content
userModal.addEventListener('click', (event) => {
    // Check if the clicked element is the modal itself (the backdrop)
    if (event.target === userModal) {
        userModal.style.display = 'none';
    }
});

// Function to append a message to the chat area
/**
 * Appends a message to the chat area.
 * @param {Object} msg - The message object containing user and message.
 * @param {string} type - The type of message ('incoming' or 'outgoing').
 */
function appendMessage(msg, type) {
    let mainDiv = document.createElement('div');
    mainDiv.classList.add(type, 'message');
    let messageContent = `<h4>${msg.user}</h4><p>${msg.message}</p>`;
    mainDiv.innerHTML = messageContent;
    messageArea.appendChild(mainDiv);
    messageArea.scrollTop = messageArea.scrollHeight;
}

// Function to append media to the chat area
/**
 * Appends media to the chat area.
 * @param {Object} mediaObj - The media object containing media data and type.
 * @param {string} type - The type of media ('incoming' or 'outgoing').
 */
function appendMedia(mediaObj, type) {
    let mainDiv = document.createElement('div');
    mainDiv.classList.add(type, 'message');

    let mediaElement;
    if (mediaObj.type === 'image') {
        mediaElement = document.createElement('img');
        mediaElement.src = mediaObj.media;
        mediaElement.style.maxWidth = '200px';
        mediaElement.style.display = 'block';
        mediaElement.style.marginTop = '5px';
    } else if (mediaObj.type === 'audio') {
        mediaElement = document.createElement('audio');
        mediaElement.src = mediaObj.media;
        mediaElement.controls = true;
        mediaElement.style.display = 'block';
        mediaElement.style.marginTop = '5px';
    } else if (mediaObj.type === 'video') {
        mediaElement = document.createElement('video');
        mediaElement.src = mediaObj.media;
        mediaElement.controls = true;
        mediaElement.style.maxWidth = '300px';
        mediaElement.style.display = 'block';
        mediaElement.style.marginTop = '5px';
    }

    if (mediaElement) {
        mainDiv.appendChild(mediaElement);
        messageArea.appendChild(mainDiv);
        messageArea.scrollTop = messageArea.scrollHeight;
    }
}

// Function to generate a unique room code
function generateRoomCode() {
    return Math.random().toString(36).substr(2, 7).toUpperCase();
}   

// Listen for paste events on the textarea
textarea.addEventListener('paste', (event) => {
    const items = (event.clipboardData || event.originalEvent.clipboardData).items;
    let mediaFound = false;

    for (let index in items) {
        const item = items[index];
        if (item.kind === 'file') {
            const blob = item.getAsFile();
            const mimeType = blob.type;
            const reader = new FileReader();

            if (mimeType.startsWith('image/')) {
                reader.onload = function(event) {
                    const imageData = event.target.result;
                    const text = textarea.value.trim();
                    appendMessage({ user: name, message: text }, 'outgoing');
                    socket.emit('message', { msg: { user: name, message: text }, roomCode });
                    sendMedia(imageData, 'image');
                };
                reader.readAsDataURL(blob);
                mediaFound = true;
                break; // Handle one media file at a time
            } else if (mimeType === 'audio/mpeg' || mimeType === 'audio/mp3') {
                reader.onload = function(event) {
                    const audioData = event.target.result;
                    const text = textarea.value.trim();
                    appendMessage({ user: name, message: text }, 'outgoing');
                    socket.emit('message', { msg: { user: name, message: text }, roomCode });
                    sendMedia(audioData, 'audio');
                };
                reader.readAsDataURL(blob);
                mediaFound = true;
                break;
            } else if (mimeType === 'video/mp4') {
                reader.onload = function(event) {
                    const videoData = event.target.result;
                    const text = textarea.value.trim();
                    appendMessage({ user: name, message: text }, 'outgoing');
                    socket.emit('message', { msg: { user: name, message: text }, roomCode });
                    sendMedia(videoData, 'video');
                };
                reader.readAsDataURL(blob);
                mediaFound = true;
                break;
            }
        }
    }

    if (mediaFound) {
        // Prevent the default paste behavior
        event.preventDefault();
    }
});

// Drag and Drop functionality
dropZone.addEventListener('dragover', (event) => {
    event.preventDefault();
    dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', (event) => {
    event.preventDefault();
    dropZone.classList.remove('dragover');
    const files = event.dataTransfer.files;
    if (files.length === 0) return;

    const file = files[0];
    const mimeType = file.type;
    const reader = new FileReader();

    if (mimeType.startsWith('image/')) {
        reader.onload = function(event) {
            const imageData = event.target.result;
            const text = textarea.value.trim();
            appendMessage({ user: name, message: text }, 'outgoing');
            socket.emit('message', { msg: { user: name, message: text }, roomCode });
            sendMedia(imageData, 'image');
        };
        reader.readAsDataURL(file);
    } else if (mimeType === 'audio/mpeg' || mimeType === 'audio/mp3') {
        reader.onload = function(event) {
            const audioData = event.target.result;
            const text = textarea.value.trim();
            appendMessage({ user: name, message: text }, 'outgoing');
            socket.emit('message', { msg: { user: name, message: text }, roomCode });
            sendMedia(audioData, 'audio');
        };
        reader.readAsDataURL(file);
    } else if (mimeType === 'video/mp4') {
        reader.onload = function(event) {
            const videoData = event.target.result;
            const text = textarea.value.trim();
            appendMessage({ user: name, message: text }, 'outgoing');
            socket.emit('message', { msg: { user: name, message: text }, roomCode });
            sendMedia(videoData, 'video');
        };
        reader.readAsDataURL(file);
    } else {
        alert('Unsupported file type.');
    }
});

// Upload media from URL
uploadUrlButton.addEventListener('click', () => {
    const url = mediaUrlInput.value.trim();
    if (url === '') {
        alert('Please enter a valid media URL.');
        return;
    }

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            const contentType = response.headers.get('Content-Type');
            if (contentType.startsWith('image/')) {
                return response.blob().then(blob => ({ blob, type: 'image' }));
            } else if (contentType === 'audio/mpeg' || contentType === 'audio/mp3') {
                return response.blob().then(blob => ({ blob, type: 'audio' }));
            } else if (contentType === 'video/mp4') {
                return response.blob().then(blob => ({ blob, type: 'video' }));
            } else {
                throw new Error('Unsupported media type.');
            }
        })
        .then(({ blob, type }) => {
            const reader = new FileReader();
            reader.onload = function(event) {
                const mediaData = event.target.result;
                const text = textarea.value.trim();
                appendMessage({ user: name, message: text }, 'outgoing');
                socket.emit('message', { msg: { user: name, message: text }, roomCode });
                sendMedia(mediaData, type);
            };
            reader.readAsDataURL(blob);
        })
        .catch(error => {
            console.error('Error fetching media:', error);
            alert('Failed to fetch media from the provided URL.');
        });
});

// Function to send media
/**
 * Sends media data to the server.
 * @param {string} mediaData - The Base64 media data.
 * @param {string} type - The type of media ('image', 'audio', 'video').
 */
function sendMedia(mediaData, type) {
    socket.emit('media', { roomCode, media: mediaData });
    appendMedia({ media: mediaData, type }, 'outgoing');
}
